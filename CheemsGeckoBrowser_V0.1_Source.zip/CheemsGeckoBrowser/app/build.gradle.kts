plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "io.cheems.browser"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.cheems.browser"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // 已发布的 GeckoView 完整通用构建（Mozilla Maven 仓库）。
    // 发布浏览器前应及时更新至 GeckoView 最新稳定安全版本。
    implementation("org.mozilla.geckoview:geckoview-omni:158.0.20261021001945")
}
