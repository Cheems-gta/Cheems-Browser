package io.cheems.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Build
import android.view.WindowInsets
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.net.Uri
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import kotlin.math.min

/**
 * Cheems Browser V0.1
 * 原生 Kotlin 界面 + Firefox GeckoView 引擎，不使用 Android WebView。
 * V0.1 仅用于初步试用：暂不支持文件上传、相机/麦克风授权、下载及数据恢复。
 */
class MainActivity : Activity() {

    companion object {
        // GeckoRuntime 每个进程只创建一次。
        private var sharedRuntime: GeckoRuntime? = null
        private const val SEARCH_ENDPOINT = "https://www.bing.com/search?q="
    }

    private data class BrowserTab(
        val session: GeckoSession,
        var url: String = "",
        var title: String = "新标签页",
        var atHome: Boolean = true,
        var canBack: Boolean = false,
        var canForward: Boolean = false
    )

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTab = 0

    private lateinit var engineView: GeckoView
    private lateinit var homeView: View
    private lateinit var address: EditText
    private lateinit var loading: ProgressBar
    private lateinit var backButton: TextView
    private lateinit var forwardButton: TextView
    private lateinit var tabButton: TextView

    private val runtime: GeckoRuntime
        get() {
            if (sharedRuntime == null) {
                sharedRuntime = GeckoRuntime.create(applicationContext)
            }
            return sharedRuntime!!
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 13, 28)
        window.navigationBarColor = Color.rgb(8, 13, 28)
        buildInterface()
        newTab()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(fill: Int, radius: Int = 17, stroke: Int? = null): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            if (stroke != null) setStroke(dp(1), stroke)
        }
    }

    private fun label(text: String, size: Float = 17f, color: Int = Color.WHITE): TextView =
        TextView(this).apply {
            this.text = text
            this.textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
        }

    private fun navButton(text: String): TextView = label(text, 20f).apply {
        background = rounded(Color.argb(75, 255, 255, 255), 15,
            Color.argb(36, 255, 255, 255))
        isClickable = true
        isFocusable = true
    }

    private fun withMargins(
        width: Int, height: Int, left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0
    ): LinearLayout.LayoutParams = LinearLayout.LayoutParams(width, height).apply {
        setMargins(dp(left), dp(top), dp(right), dp(bottom))
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 13, 28))
        }
        setContentView(root)
        // Android 15+ 的强制 edge-to-edge：让地址栏与导航按钮避开系统状态栏。
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(0, bars.top, 0, bars.bottom)
                insets
            }
        }

        // 顶部地址栏：可以输入网址，也可以直接搜索关键词。
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(11), dp(8), dp(11), dp(8))
        }
        root.addView(toolbar, withMargins(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)))

        val brand = navButton("🦊").apply {
            contentDescription = "回到主页"
            setOnClickListener { showHome() }
        }
        toolbar.addView(brand, withMargins(dp(46), dp(46), 0, 0, 8, 0))

        address = EditText(this).apply {
            hint = "搜索，或输入网址"
            setHintTextColor(Color.rgb(157, 166, 186))
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI
            background = rounded(Color.rgb(30, 38, 60), 16,
                Color.rgb(75, 85, 111))
            setPadding(dp(14), 0, dp(12), 0)
            setSelectAllOnFocus(true)
            setOnEditorActionListener { _, action, event ->
                if (action == EditorInfo.IME_ACTION_GO ||
                    (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                ) {
                    navigate(text.toString())
                    true
                } else false
            }
        }
        toolbar.addView(address, LinearLayout.LayoutParams(0, dp(46), 1f))

        val go = navButton("➜").apply {
            contentDescription = "访问或搜索"
            setOnClickListener { navigate(address.text.toString()) }
        }
        toolbar.addView(go, withMargins(dp(46), dp(46), 8, 0, 0, 0))

        loading = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            visibility = View.GONE
            progressTintList = ColorStateList.valueOf(Color.rgb(123, 196, 255))
            progressBackgroundTintList = Color.rgb(8, 13, 28)
        }
        root.addView(loading, withMargins(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        val canvas = FrameLayout(this)
        root.addView(canvas, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        engineView = GeckoView(this)
        canvas.addView(engineView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        homeView = makeHome()
        canvas.addView(homeView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        root.addView(bottom, withMargins(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)))

        backButton = navButton("‹").apply {
            contentDescription = "后退"
            textSize = 30f
            setOnClickListener { goBack() }
        }
        forwardButton = navButton("›").apply {
            contentDescription = "前进"
            textSize = 30f
            setOnClickListener {
                val tab = currentTab()
                if (tab.canForward) tab.session.goForward()
            }
        }
        val home = navButton("⌂").apply {
            textSize = 25f
            contentDescription = "主页"
            setOnClickListener { showHome() }
        }
        val reload = navButton("↻").apply {
            contentDescription = "刷新页面"
            textSize = 26f
            setOnClickListener {
                val tab = currentTab()
                if (tab.atHome) return@setOnClickListener
                tab.session.reload()
            }
        }
        tabButton = navButton("1").apply {
            textSize = 17f
            contentDescription = "管理标签页"
            setOnClickListener { showTabPicker() }
        }
        listOf(backButton, forwardButton, home, reload, tabButton).forEach { button ->
            bottom.addView(button, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
    }

    private fun makeHome(): View {
        val backdrop = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(19, 37, 78), Color.rgb(12, 18, 40), Color.rgb(32, 24, 64))
        )
        return ScrollView(this).apply {
            background = backdrop
            isFillViewport = true
            val center = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(22), dp(60), dp(22), dp(28))
            }
            addView(center)

            center.addView(label("✦  ·  ✧  ·  ✦", 20f, Color.rgb(163, 186, 255)))
            center.addView(label("CHEEMS", 37f).apply {
                typeface = Typeface.create("sans-serif-light", Typeface.BOLD)
                letterSpacing = 0.13f
            }, withMargins(ViewGroup.LayoutParams.MATCH_PARENT, dp(72), 0, 16))
            center.addView(label("BROWSER  /  GECKO ENGINE", 11f,
                Color.rgb(160, 185, 231)))
            center.addView(label("一个真正使用 Firefox 内核的 Android 浏览器", 14f,
                Color.rgb(190, 205, 228)), withMargins(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(68), 0, 15))

            val homeSearch = EditText(this@MainActivity).apply {
                hint = "搜索网页或输入网址…"
                setHintTextColor(Color.rgb(160, 175, 196))
                setTextColor(Color.WHITE)
                textSize = 16f
                setSingleLine(true)
                imeOptions = EditorInfo.IME_ACTION_SEARCH
                background = rounded(Color.argb(85, 255, 255, 255), 22,
                    Color.argb(90, 255, 255, 255))
                setPadding(dp(17), 0, dp(17), 0)
                setOnEditorActionListener { _, actionId, _ ->
                    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                        navigate(text.toString())
                        setText("")
                        true
                    } else false
                }
            }
            center.addView(homeSearch, withMargins(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(59), 0, 8))

            center.addView(label("快捷入口", 14f,
                Color.rgb(164, 191, 238)).apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
            }, withMargins(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 3, 16))

            val links = listOf(
                "Mozilla" to "https://www.mozilla.org/",
                "维基百科" to "https://www.wikipedia.org/",
                "GitHub" to "https://github.com/",
                "MDN 文档" to "https://developer.mozilla.org/"
            )
            links.chunked(2).forEach { rowLinks ->
                val row = LinearLayout(this@MainActivity)
                center.addView(row, withMargins(ViewGroup.LayoutParams.MATCH_PARENT, dp(68)))
                rowLinks.forEach { (name, url) ->
                    val tile = label(name, 15f).apply {
                        background = rounded(Color.argb(56, 255, 255, 255), 18,
                            Color.argb(70, 255, 255, 255))
                        setOnClickListener { navigate(url) }
                    }
                    row.addView(tile, LinearLayout.LayoutParams(0, dp(56), 1f).apply {
                        setMargins(dp(5), dp(4), dp(5), dp(4))
                    })
                }
            }
            center.addView(label("CHEEMS  ·  V0.1", 12f,
                Color.rgb(136, 157, 200)), withMargins(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(74), 0, 20))
        }
    }

    private fun createSession(): GeckoSession {
        val session = GeckoSession()
        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                val tab = findTab(session) ?: return
                tab.title = title?.takeIf { it.isNotBlank() } ?: "网页"
            }
        }
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: List<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                val tab = findTab(session) ?: return
                if (!url.isNullOrBlank()) {
                    tab.url = url
                    tab.atHome = false
                }
                if (isCurrent(tab)) {
                    address.setText(tab.url)
                    showContent(tab)
                }
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                findTab(session)?.let {
                    it.canBack = canGoBack
                    if (isCurrent(it)) updateControls()
                }
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                findTab(session)?.let {
                    it.canForward = canGoForward
                    if (isCurrent(it)) updateControls()
                }
            }

            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession> {
                // 网页 window.open / target=_blank 新建独立标签。
                val newTab = newTab()
                return GeckoResult.fromValue(newTab.session)
            }
        }
        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                if (isCurrentSession(session)) {
                    loading.progress = 5
                    loading.visibility = View.VISIBLE
                }
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                if (isCurrentSession(session)) {
                    loading.progress = progress
                    loading.visibility = if (progress >= 100) View.GONE else View.VISIBLE
                }
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                if (isCurrentSession(session)) loading.visibility = View.GONE
            }
        }
        session.open(runtime)
        return session
    }

    private fun newTab(): BrowserTab {
        val tab = BrowserTab(createSession())
        tabs.add(tab)
        switchTo(tabs.lastIndex)
        return tab
    }

    private fun currentTab(): BrowserTab = tabs[activeTab]
    private fun findTab(session: GeckoSession): BrowserTab? = tabs.firstOrNull { it.session === session }
    private fun isCurrent(tab: BrowserTab): Boolean = tabs.getOrNull(activeTab) === tab
    private fun isCurrentSession(session: GeckoSession): Boolean =
        tabs.getOrNull(activeTab)?.session === session

    private fun switchTo(index: Int) {
        if (index !in tabs.indices) return
        if (tabs.isNotEmpty() && activeTab in tabs.indices) {
            tabs[activeTab].session.setActive(false)
        }
        activeTab = index
        val tab = currentTab()
        if (engineView.session !== tab.session) {
            engineView.releaseSession()
            engineView.setSession(tab.session)
        }
        tab.session.setActive(true)
        address.setText(if (tab.atHome) "" else tab.url)
        showContent(tab)
        updateControls()
        loading.visibility = View.GONE
    }

    private fun showContent(tab: BrowserTab) {
        homeView.visibility = if (tab.atHome) View.VISIBLE else View.GONE
        engineView.visibility = if (tab.atHome) View.GONE else View.VISIBLE
    }

    private fun showHome() {
        val tab = currentTab()
        tab.atHome = true
        address.setText("")
        hideKeyboard()
        showContent(tab)
        updateControls()
        loading.visibility = View.GONE
    }

    private fun navigate(raw: String) {
        val input = raw.trim()
        if (input.isBlank()) return
        val url = normalizeAddress(input)
        val tab = currentTab()
        tab.atHome = false
        tab.url = url
        address.setText(url)
        address.clearFocus()
        hideKeyboard()
        showContent(tab)
        tab.session.loadUri(url)
        updateControls()
    }

    private fun normalizeAddress(text: String): String {
        val query = text.trim()
        if (query.equals("about:blank", ignoreCase = true)) return "about:blank"
        if (query.startsWith("https://", true) || query.startsWith("http://", true)) {
            return query
        }
        // 其他 scheme（如 javascript:、file:）不当成地址执行。
        val looksLikeHost = !query.contains(Regex("\\s")) &&
            !query.contains(":") &&
            (query.contains('.') || query.equals("localhost", ignoreCase = true))
        return if (looksLikeHost) "https://$query" else SEARCH_ENDPOINT + Uri.encode(query)
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(address.windowToken, 0)
    }

    private fun goBack() {
        val tab = currentTab()
        if (tab.atHome && tab.url.isNotBlank()) {
            tab.atHome = false
            address.setText(tab.url)
            showContent(tab)
        } else if (tab.canBack && !tab.atHome) {
            tab.session.goBack()
        } else if (!tab.atHome) {
            showHome()
        }
        updateControls()
    }

    private fun updateControls() {
        if (tabs.isEmpty()) return
        val tab = currentTab()
        // 主页叠层可以通过后退返回之前的网页。
        val backEnabled = (tab.atHome && tab.url.isNotBlank()) ||
            (!tab.atHome && (tab.canBack || tab.url.isNotBlank()))
        backButton.alpha = if (backEnabled) 1f else 0.36f
        forwardButton.alpha = if (!tab.atHome && tab.canForward) 1f else 0.36f
        tabButton.text = tabs.size.toString()
    }

    private fun showTabPicker() {
        val names = tabs.mapIndexed { index, tab ->
            "${if (index == activeTab) "●" else "○"}  ${index + 1}. ${tab.title.take(28)}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("标签页 · ${tabs.size}")
            .setItems(names) { _, which -> switchTo(which) }
            .setPositiveButton("＋ 新标签") { _, _ -> newTab() }
            .setNeutralButton("关闭当前") { _, _ -> closeCurrentTab() }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun closeCurrentTab() {
        if (tabs.isEmpty()) return
        val closed = currentTab()
        if (engineView.session === closed.session) engineView.releaseSession()
        tabs.removeAt(activeTab)
        closed.session.close()
        if (tabs.isEmpty()) {
            activeTab = 0
            newTab()
        } else {
            // 先把 activeTab 调整到一个存在的下标。
            activeTab = min(activeTab, tabs.lastIndex)
            switchTo(activeTab)
        }
    }

    @Deprecated("Old back dispatcher kept for a minimal Activity without AndroidX")
    override fun onBackPressed() {
        val tab = currentTab()
        if (tab.atHome) {
            if (tab.url.isNotBlank()) goBack() else super.onBackPressed()
        } else {
            goBack()
        }
    }

    override fun onDestroy() {
        engineView.releaseSession()
        tabs.forEach { it.session.close() }
        tabs.clear()
        super.onDestroy()
    }
}
