# Cheems Browser V0.1 🦊

这是一个**原生 Android/Kotlin 浏览器原型工程**。引擎是 Mozilla GeckoView/Gecko + SpiderMonkey，**不是 Android WebView 套壳**。

## 已实现

- GeckoView 网页加载、HTML/CSS/JavaScript 渲染与触控滚动
- 输入网址，或者通过 Bing 搜索关键词
- 原生深色首页与快捷入口
- 前进、后退、刷新、返回主页
- 基础多标签页切换、新建、关闭
- 加载进度、地址栏 URL 同步、网页标题
- 网页要求的新窗口（window.open / target=_blank）进入新标签页

## V0.1 的明确限制

- **还没有实现**下载管理、文件上传选择器、摄像头/麦克风授权、历史记录持久化、书签、WebRTC 提示、会话恢复、密码存储、网页分享等。这些不是完整浏览器的最终实现。
- V0.1 的首页是原生 Android UI，暂未迁移已有 Cheems 网站的完整视觉效果。
- Activity 重建后当前标签页不恢复（应用关闭后历史状态不保留）。
- 测试版本；没有跑过真机编译/回归测试，不应直接当作主力浏览器使用。

## 方法一：用 Android Studio 构建

要求：**JDK 17、Android SDK 35、Gradle 8.11.1**。

1. 解压压缩包，Android Studio -> Open -> 选 `CheemsGeckoBrowser` 文件夹。
2. 首次打开时允许下载 Gradle 插件和 GeckoView AAR，联网同步依赖。
3. 项目使用 `build.gradle.kts`：AGP 8.10.0、Kotlin 2.2.20、GeckoView 158.0.20261021001945。
4. 本项目没有内置 Gradle Wrapper JAR；如果 Android Studio 提示缺少 Wrapper，可在本机安装的 Gradle 8.11.1 执行 `gradle wrapper --gradle-version 8.11.1`，之后再使用 `./gradlew :app:assembleDebug`。
5. 安装手机/模拟器并运行，或运行 `gradle :app:assembleDebug`。
6. 编译成功后 APK 路径：`app/build/outputs/apk/debug/app-debug.apk`。

## 方法二：GitHub Actions 云端构建（无需本机安装 Android SDK）

1. 新建一个 GitHub 仓库，把 **CheemsGeckoBrowser 文件夹里的内容**上传到仓库根目录，保持 `.github/workflows/android-build.yml` 目录完整。
2. 仓库 Actions 页面运行 `Build Cheems Browser Debug APK` 工作流，或者提交到 `main` 分支自动触发。
3. 工作流成功后从该次运行的 `Artifacts` 下载 `CheemsBrowser-V0.1-Debug`，解压获得 `app-debug.apk`。
4. APK 由 GitHub runner 编译；**压缩包本身不是 APK**。若首次同步失败，检查依赖下载/网络/Android SDK 日志。

## 核心文件位置

- `app/src/main/java/io/cheems/browser/MainActivity.kt` - 浏览器与 UI 的实现
- `app/src/main/AndroidManifest.xml` - 应用信息与网络权限
- `app/build.gradle.kts` - Android 构建与 GeckoView 依赖
- `.github/workflows/android-build.yml` - 云端 APK 构建

## 技术说明

- GeckoView 官方：https://mozilla.github.io/geckoview/
- GeckoView 启动指南：https://mozilla.github.io/geckoview/consumer/docs/geckoview-quick-start
- Maven 镜像库：https://maven.mozilla.org/maven2/
- GeckoView 代码遵循 Mozilla Public License 2.0；若修改 Gecko 内核源码，请遵守对应许可要求。
- 为避免浏览器引擎漏洞，请定期更新至 GeckoView 的新稳定版本并重新构建。

## 后续计划

V0.2：引入完整 Cheems 液态玻璃风格；进一步完善 tab 管理、下载和文件上传。
V0.3：收藏夹、历史记录、搜索引擎切换、持久化与更完整的权限提示。
